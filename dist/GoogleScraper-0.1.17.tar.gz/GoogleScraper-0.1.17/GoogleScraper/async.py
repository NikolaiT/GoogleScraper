# -*- coding: utf-8 -*-

from GoogleScraper.scraping import SearchEngineScrape

class AsyncHttpScrape(SearchEngineScrape):
    pass

